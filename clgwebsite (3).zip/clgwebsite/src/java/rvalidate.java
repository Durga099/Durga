
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class rvalidate extends HttpServlet {
private static final long serialVersionUID = 1L;
       
    
@Override
     protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
                
         try{
             Connection conn =  h2connect.initializeDatabase();
         
             PreparedStatement st = conn.prepareStatement("insert into Registration values(?,?,?,?,?)");
     
              st.setString(1, request.getParameter("first_name")); 
              st.setString(2, request.getParameter("last_name"));
              st.setString(3, request.getParameter("username"));
              st.setString(4, request.getParameter("password"));
              st.setString(5, request.getParameter("address"));
              st.executeUpdate(); 
            st.close(); 
            conn.close(); 
            PrintWriter out = response.getWriter(); 
            out.println("<html><body><b>Successfully Inserted"
                        + "</b></body></html>"); 
             response.sendRedirect("register2.jsp");
        } 
        catch (Exception e) 
        { 
            e.printStackTrace(); 
        } 
     }
}
    